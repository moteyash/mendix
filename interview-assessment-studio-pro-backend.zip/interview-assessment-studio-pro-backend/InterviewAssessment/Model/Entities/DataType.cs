﻿namespace DomainModelEditor.Model.Entities
{
    public enum DataType
    {
        String = 1,
        Int = 2
    }
}