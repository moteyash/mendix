﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace DomainModelEditor
{
    public class EntityInfo
    {
        public string Name { get; set; }
        // Add additional properties for attributes if needed
    }

    public class EntityXamlParser
    {
        public static List<EntityInfo> ParseEntities(string filePath)
        {
            List<EntityInfo> entities = new List<EntityInfo>();

            XDocument xdoc = XDocument.Load(filePath);

            // Define the namespace
            XNamespace ns = "http://schemas.microsoft.com/winfx/2006/xaml/presentation";

            // Find all UserControl elements with x:Class="DomainModelEditor.UserControl.Entity"
            var userControlNodes = xdoc.Descendants(ns + "UserControl")
                                        .Where(e => (string)e.Attribute(ns + "Class") == "DomainModelEditor.UserControl.Entity");

            foreach (var userControlNode in userControlNodes)
            {
                var labelNode = userControlNode.Descendants(ns + "Label").FirstOrDefault();
                if (labelNode != null)
                {
                    EntityInfo entity = new EntityInfo
                    {
                        Name = (string)labelNode.Attribute(ns + "Content")
                    };
                    entities.Add(entity);
                }
            }

            return entities;
        }
    }

    }
