﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using System.Xml;

namespace DomainModelEditor.View.Dialog
{
    /// <summary>
    /// Interaction logic for NamePrompt.xaml
    /// </summary>
    public partial class GenerateSchemaDialog : Window
    {
        public bool Continue { get; set; }

        public GenerateSchemaDialog()
        {
            InitializeComponent();
        }


        private void Generate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Read domain model from XAML file
                XmlDocument xamlDocument = new XmlDocument();
                xamlDocument.Load("C://Users//yash-j//Downloads//interview-assessment-studio-pro-backend//InterviewAssessment//View//MainWindow.xaml");

                // Parse entities from XAML document
                List<EntityInfo> entities = EntityXamlParser.ParseEntities("C://Users//yash-j//Downloads//interview-assessment-studio-pro-backend//InterviewAssessment//UserControl//Entity.xaml");


                // Generate schema and save to file
                GenerateSFCDBSchema(xamlDocument);
                Continue = true;
                MessageBox.Show("Schema generated successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error generating schema: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                Close();
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void GenerateSFCDBSchema(XmlDocument xamlDocument)
        {
            StringBuilder schemaBuilder = new StringBuilder();

            // Iterate through entities in the XAML document
            XmlNodeList entityNodes = xamlDocument.SelectNodes("//Grid");
            foreach (XmlNode entityNode in entityNodes)
            {
                string entityName = entityNode.Attributes["Name"].Value;
                schemaBuilder.AppendLine($"START DATASTORE DEFINITION FOR: {entityName}");

                // Iterate through attributes of the entity
                XmlNodeList attributeNodes = entityNode.SelectNodes("Attribute");
                foreach (XmlNode attributeNode in attributeNodes)
                {
                    string attributeName = attributeNode.Attributes["Name"].Value;
                    string attributeType = attributeNode.Attributes["Type"].Value;

                    // Map attribute types from XAML to SFCDB types
                    string sfcdbType;
                    switch (attributeType.ToLower())
                    {
                        case "string":
                            sfcdbType = "unlimited_text";
                            break;
                        case "int":
                            sfcdbType = "numerical";
                            break;
                        default:
                            throw new InvalidOperationException($"Unsupported attribute type: {attributeType}");
                    }

                    schemaBuilder.AppendLine($"PROP");
                    schemaBuilder.AppendLine($"  NAME: {attributeName}");
                    schemaBuilder.AppendLine($"  TYPE: {sfcdbType}");
                }

                schemaBuilder.AppendLine($"END DATASTORE DEFINITION");
                schemaBuilder.AppendLine("// ---");
            }

            // Save schema to file
            string filePath = "SFCDB_Schema.dml";
            File.WriteAllText(filePath, schemaBuilder.ToString(), Encoding.UTF8);
        }
    }
    }